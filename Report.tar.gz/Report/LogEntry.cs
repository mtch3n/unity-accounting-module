using Report.Data;

namespace Report
{
    public class LogEntry
    {
        public long index;
        public ReportType type;
        public long value;
    }
}