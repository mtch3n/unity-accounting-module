namespace Report
{
    public class WAL
    {
        private const int WalLimit = 1000;
        private int index;

        private LogEntry[] entries;
    }
}